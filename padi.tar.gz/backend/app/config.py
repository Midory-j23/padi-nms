from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    librenms_url: str = ""
    librenms_api_token: str = ""
    request_timeout: float = 10.0
    cache_ttl: int = 15
    verify_ssl: bool = True
    mock_fallback: bool = True
    # MongoDB for the app's own data (clients, audit log). Empty = feature off; monitoring works without it.
    mongodb_uri: str = ""
    mongodb_db: str = "padi_nms"
    # Copy LibreNMS logs (eventlog, syslog, alertlog) into MongoDB every N seconds. 0 = off. Needs MONGODB_URI.
    log_collect_interval: int = 60
    cors_origins: str = "http://localhost:5173"
    # Open-port check: by default only private / local addresses may be checked.
    allow_public_scan: bool = False
    # Sign-in. Users and sessions live in a small SQLite file (default: backend/data/padi.db).
    auth_db_path: str = ""
    session_hours: int = 12             # normal sign-in lifetime
    session_remember_days: int = 30     # lifetime when "stay signed in" is ticked
    # Prometheus (optional)
    prometheus_url: str = ""            # where Padi READS metrics from, e.g. http://localhost:9090
    metrics_token: str = ""             # if set, GET /metrics requires "Authorization: Bearer <token>"
    metrics_include_ports: bool = False  # per-port series on /metrics (can be thousands of series)


settings = Settings()
