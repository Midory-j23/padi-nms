import asyncio
import logging

from fastapi import Depends, FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.auth_routes import router as auth_router, users_router
from app.api.prometheus import metrics_router, router as prom_router
from app.api.routes import router
from app.auth import all_user_records, authorize
from app.config import settings
from app.services import collector, db
from app.services.librenms import LibreNMSError

log = logging.getLogger("librenms-ui")
app = FastAPI(title="LibreNMS UI Backend", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=[o.strip() for o in settings.cors_origins.split(",") if o.strip()],  # "*" allows any
                   allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"], allow_headers=["Authorization", "Content-Type"])
# Every data route requires sign-in; observers are read-only (see app/auth.py).
app.include_router(auth_router)
app.include_router(users_router)
app.include_router(router, dependencies=[Depends(authorize)])
app.include_router(prom_router, dependencies=[Depends(authorize)])
app.include_router(metrics_router)  # Prometheus scraping uses its own METRICS_TOKEN


@app.on_event("startup")
async def _startup():
    # Indexes, one-time copy of the old `clients` collection, and a full copy of the users into MongoDB.
    try:
        users = await asyncio.to_thread(all_user_records)
    except Exception:  # noqa: BLE001
        log.exception("Could not read the users for the MongoDB copy")
        users = []
    await db.init(users)
    app.state.collector = asyncio.create_task(collector.run())


@app.on_event("shutdown")
async def _shutdown():
    task = getattr(app.state, "collector", None)
    if task:
        task.cancel()
    await db.close()


@app.exception_handler(LibreNMSError)
async def lnms_error(_: Request, e: LibreNMSError):
    return JSONResponse({"error": {"code": e.code, "message": e.message}}, status_code=e.status)


@app.exception_handler(Exception)
async def unexpected(_: Request, e: Exception):
    log.exception("Unhandled error")  # details stay in server logs only
    return JSONResponse({"error": {"code": "internal", "message": "Unexpected server error."}}, status_code=500)
